/* Mini K avatar artwork. No wallet access or network requests. */
(() => {
  'use strict';
  const options = {
    network: ['ethereum','bitcoin'],
    backdrop: ['solid','grid','space','sunset','halo','transparent'],
    body: ['straight','tapered','rounded'],
    build: ['slim','regular','broad'],
    hair: ['short','curls','long','mohawk','bald'],
    hat: ['none','cap','beanie','crown'],
    clothes: ['hoodie','tee','jacket','suit'],
    bottoms: ['pants','shorts'],
    shoes: ['sneakers','boots','high-tops'],
    accessory: ['none','glasses','sunglasses'],
    beard: ['none','short','full'],
    emblem: ['K','BTC','ETH','none']
  };
  const defaults = {name:'Mini K / Genesis',network:'ethereum',body:'straight',build:'regular',height:100,skin:'#d9a079',hair:'short',hairColor:'#30251f',hat:'none',hatColor:'#a78bfa',clothes:'hoodie',topColor:'#f7931a',bottoms:'pants',bottomColor:'#344054',shoes:'sneakers',shoeColor:'#f5f3ff',accessory:'none',beard:'short',emblem:'BTC',background:'#10182b',accent:'#67e8f9'};
  const colors=['skin','hairColor','hatColor','topColor','bottomColor','shoeColor','background','accent'];
  defaults.backdrop='halo';
  defaults.strokes=[];
  const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
  function validate(raw){
    if(!raw || typeof raw!=='object')throw Error('Invalid avatar.');
    const d={};
    if(typeof raw.name!=='string'||!raw.name.trim()||raw.name.length>36)throw Error('Use an avatar name of 1–36 characters.');
    d.name=raw.name.trim();
    for(const [k,v] of Object.entries(options)){if(!v.includes(raw[k]))throw Error('Invalid '+k+'.');d[k]=raw[k];}
    for(const k of colors){if(typeof raw[k]!=='string'||!/^#[a-f0-9]{6}$/i.test(raw[k]))throw Error('Invalid '+k+'.');d[k]=raw[k];}
    d.height=Number(raw.height);
    if(!Number.isInteger(d.height)||d.height<80||d.height>120)throw Error('Height must be 80–120.');
    if(!Array.isArray(raw.strokes)||raw.strokes.length>200)throw Error('Maximum 200 paint strokes.');
    d.strokes=raw.strokes.map(s=>{
      if(!s||!['brush','eraser'].includes(s.tool)||!/^#[a-f0-9]{6}$/i.test(s.color)||!Number.isFinite(s.size)||s.size<2||s.size>60||!Array.isArray(s.points)||s.points.length<1||s.points.length>400)throw Error('Invalid paint stroke.');
      const points=s.points.map(p=>{if(!Array.isArray(p)||p.length!==2||!p.every(n=>Number.isFinite(n)&&n>=0&&n<=800))throw Error('Invalid paint coordinates.');return [...p];});
      return {tool:s.tool,color:s.color,size:s.size,points};
    });
    return d;
  }
  function baseSvg(raw,transparent=false){
    const d=validate(raw),w={slim:23,regular:28,broad:35}[d.build],l=36-w/2,r=36+w/2;
    const mark={K:'K',BTC:'₿',ETH:'Ξ',none:''}[d.emblem];
    const line=(x1,y1,x2,y2,color,width)=>`<path d="M${x1} ${y1} L${x2} ${y2}" stroke="${color}" stroke-width="${width}" stroke-linecap="round"/>`;
    let hair={bald:'',short:`<path d="M20 25 Q16 7 35 7 Q55 7 52 25 L46 18 Q33 22 24 16Z" fill="${d.hairColor}"/>`,curls:`<g fill="${d.hairColor}">${[[23,17],[28,11],[36,10],[44,11],[49,17]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="7"/>`).join('')}</g>`,long:`<path d="M19 29 Q14 5 36 6 Q59 6 53 29 L48 18 Q34 25 23 18Z" fill="${d.hairColor}"/>`,mohawk:`<path d="M29 17 L30 6 L34 10 L37 1 L41 9 L45 4 L44 19Z" fill="${d.hairColor}"/>`}[d.hair];
    let hat={none:'',cap:`<path d="M19 18 Q20 2 36 3 Q51 4 52 18Z" fill="${d.hatColor}"/><path d="M18 18 H59" stroke="${d.hatColor}" stroke-width="5" stroke-linecap="round"/>`,beanie:`<path d="M18 18 Q18 1 36 2 Q54 1 54 18Z" fill="${d.hatColor}"/><rect x="18" y="15" width="36" height="7" rx="3" fill="${d.hatColor}" stroke="#ffffff" stroke-opacity=".3"/><circle cx="36" cy="2" r="4" fill="${d.hatColor}"/>`,crown:`<path d="M20 18 L18 5 L28 12 L36 1 L44 12 L54 5 L51 18Z" fill="${d.hatColor}" stroke="#ffc46b" stroke-width="1.5"/><circle cx="36" cy="13" r="2" fill="${d.accent}"/>`}[d.hat];
    let torso=d.body==='straight'?`<rect x="${l}" y="43" width="${w}" height="33" rx="8" fill="${d.topColor}"/>`:d.body==='tapered'?`<path d="M${l} 44 Q36 39 ${r} 44 L${r-4} 76 H${l+4}Z" fill="${d.topColor}"/>`:`<path d="M${l+3} 44 Q36 40 ${r-3} 44 Q${r+8} 75 ${r-1} 77 H${l+1} Q${l-8} 75 ${l+3} 44Z" fill="${d.topColor}"/>`;
    let detail={tee:'',hoodie:`<path d="M28 46 L36 52 L44 46 M30 50 V59 M42 50 V59 M29 69 Q36 66 43 69" fill="none" stroke="#ffffff" stroke-opacity=".6" stroke-width="1.2"/>`,jacket:`<path d="M36 46 V76 M${l+4} 59 H${l+9} M${r-9} 59 H${r-4}" stroke="#ffffff" stroke-opacity=".6" stroke-width="1.2"/>`,suit:`<path d="M29 43 L36 64 L43 43" fill="#f5f3ff"/><path d="M35 46 L33 57 L36 62 L39 57 L37 46Z" fill="${d.accent}"/>`}[d.clothes];
    let facial=d.beard==='none'?'':d.beard==='short'?`<path d="M25 32 Q36 46 47 32 Q36 39 25 32Z" fill="${d.hairColor}"/>`:`<path d="M22 29 Q24 44 36 47 Q49 43 50 29 L45 33 Q36 37 27 33Z" fill="${d.hairColor}"/>`;
    const glasses=d.accessory==='none'?'':`<g fill="${d.accessory==='glasses'?'none':'#121827'}" stroke="${d.accessory==='glasses'?d.accent:'#121827'}" stroke-width="1.5"><rect x="23" y="23" width="11" height="8" rx="3"/><rect x="38" y="23" width="11" height="8" rx="3"/><path d="M34 26 H38"/></g>`;
    const shoes=[{x:27,to:20},{x:45,to:52}].map(({x,to})=>`${d.shoes==='sneakers'?'':line(x,83,x,91,d.shoeColor,9)}${line(x,92,to,92,d.shoeColor,d.shoes==='boots'?10:8)}${line(Math.min(x,to)-2,96,Math.max(x,to)+2,96,'#111827',1.5)}${d.shoes==='boots'?'':line(x-2,90,x+2,90,d.accent,1.2)}`).join('');
    const s=d.height/100;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800"><title>${escape(d.name)}</title>${transparent?'':`<rect width="800" height="800" rx="32" fill="${d.background}"/><circle cx="400" cy="345" r="240" fill="none" stroke="${d.accent}" stroke-opacity=".18" stroke-width="2"/><circle cx="400" cy="345" r="200" fill="none" stroke="${d.hatColor}" stroke-opacity=".22" stroke-dasharray="5 12"/><ellipse cx="400" cy="658" rx="156" ry="22" fill="#000000" fill-opacity=".25"/><text x="42" y="54" fill="${d.accent}" font-family="sans-serif" font-size="14" letter-spacing="3">KSMB / AVATAR STUDIO</text>`}<g transform="translate(220 160) scale(5)"><g transform="translate(0 ${98*(1-s)}) scale(1 ${s})">${d.hair==='long'?`<path d="M19 20 Q10 36 17 48 H55 Q62 36 53 20Z" fill="${d.hairColor}"/>`:''}${line(30,72,27,90,d.bottoms==='shorts'?d.skin:d.bottomColor,10)}${line(42,72,45,90,d.bottoms==='shorts'?d.skin:d.bottomColor,10)}${d.bottoms==='shorts'?line(30,73,29,80,d.bottomColor,12)+line(42,73,43,80,d.bottomColor,12):''}${shoes}${line(l+2,49,l-5,66,d.clothes==='tee'?d.skin:d.topColor,9)}${line(r-2,49,r+5,66,d.clothes==='tee'?d.skin:d.topColor,9)}<circle cx="${l-5}" cy="70" r="5" fill="${d.skin}"/><circle cx="${r+5}" cy="70" r="5" fill="${d.skin}"/>${torso}${detail}${d.emblem==='ETH'?'<path d="M36 54 L31 62 L36 65 L41 62Z M31 64 L36 70 L41 64 L36 67Z" fill="#ffffff"/>':d.emblem==='BTC'?'<text x="36" y="67" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">B</text><path d="M34 55 V69 M37 55 V69" stroke="#ffffff" stroke-width=".8"/>':'<text x="36" y="67" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">'+mark+'</text>'}<rect x="31" y="35" width="10" height="12" rx="4" fill="${d.skin}"/><circle cx="20" cy="27" r="3.5" fill="${d.skin}"/><circle cx="52" cy="27" r="3.5" fill="${d.skin}"/><circle cx="36" cy="25" r="16" fill="${d.skin}"/>${hair}${facial}<circle cx="30" cy="26" r="2" fill="#171717"/><circle cx="42" cy="26" r="2" fill="#171717"/><path d="M32 33 Q36 36 40 33" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"/>${glasses}${hat}</g></g>${transparent?'':`<text x="400" y="726" text-anchor="middle" fill="#edf2ff" font-family="sans-serif" font-size="${d.name.length>24?23:30}" font-weight="bold">${escape(d.name)}</text><text x="400" y="762" text-anchor="middle" fill="${d.accent}" font-family="sans-serif" font-size="13" letter-spacing="2">${d.network.toUpperCase()} / AVATAR DRAFT</text>`}</svg>`;
  }
  function svg(raw){
    const d=validate(raw);
    let bg=d.backdrop==='transparent'?'':`<rect width="800" height="800" fill="${d.background}"/>`;
    if(d.backdrop==='grid')bg+=`<defs><pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse"><path d="M50 0H0V50" fill="none" stroke="${d.accent}" stroke-opacity=".3"/></pattern></defs><rect width="800" height="800" fill="url(#grid)"/>`;
    if(d.backdrop==='space')for(let i=0;i<90;i++)bg+=`<circle cx="${(i*137+31)%800}" cy="${(i*89+47)%800}" r="${i%3+1}" fill="${d.accent}" opacity="${.2+(i%6)/10}"/>`;
    if(d.backdrop==='sunset')bg+=`<defs><linearGradient id="sunset" x2="0" y2="1"><stop stop-color="${d.background}"/><stop offset="1" stop-color="${d.accent}"/></linearGradient></defs><rect width="800" height="800" fill="url(#sunset)"/><circle cx="400" cy="340" r="180" fill="${d.hatColor}" opacity=".5"/><path d="M0 650 L150 520 L320 660 L570 510 L800 650 V800 H0Z" fill="${d.background}" opacity=".8"/>`;
    if(d.backdrop==='halo')bg+=`<circle cx="400" cy="350" r="240" fill="none" stroke="${d.accent}" stroke-opacity=".3" stroke-width="3"/><circle cx="400" cy="350" r="205" fill="none" stroke="${d.hatColor}" stroke-width="2" stroke-dasharray="5 12"/>`;
    let paint='',masks='';
    d.strokes.forEach((stroke,i)=>{
      const p=stroke.points;
      const path=`M${p.map(v=>v.join(' ')).join(' L')}${p.length===1?' l.01 0':''}`;
      const attrs=`d="${path}" fill="none" stroke-width="${stroke.size}" stroke-linecap="round" stroke-linejoin="round"`;
      if(stroke.tool==='eraser'){
        masks+=`<mask id="erase${i}" maskUnits="userSpaceOnUse" x="0" y="0" width="800" height="800"><rect width="800" height="800" fill="white"/><path ${attrs} stroke="black"/></mask>`;
        paint=`<g mask="url(#erase${i})">${paint}</g>`;
      }else paint+=`<path ${attrs} stroke="${stroke.color}"/>`;
    });
    const character=baseSvg(d,true).replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'');
    const caption=d.backdrop==='transparent'?'':`<text x="40" y="48" fill="${d.accent}" font-family="sans-serif" font-size="14" letter-spacing="3">KSMB / AVATAR STUDIO</text><text x="400" y="728" text-anchor="middle" fill="white" font-family="sans-serif" font-size="${d.name.length>24?23:30}">${escape(d.name)}</text><text x="400" y="767" text-anchor="middle" fill="${d.accent}" font-family="sans-serif" font-size="13">${d.network.toUpperCase()} / AVATAR DRAFT</text>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">${bg}${character}<defs>${masks}</defs>${caption}${paint}</svg>`;
  }
  const api={options,defaults,validate,svg};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else window.KSMBAvatarDesign=api;
})();
