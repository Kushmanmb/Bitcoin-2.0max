# Mini K — Build Your Blockchain Avatar

Adds an isolated avatar editor ABOVE the existing NFT Studio artwork designer. It is based on the site's Mini K character; it does not replace the roaming Mini K or alter the existing artwork gallery.

## Included controls

Skin tone; straight/tapered/rounded body; slim/regular/broad build; height; short/curly/long/mohawk/bald hair; hair and beard color; beard; cap/beanie/crown; hat color; glasses/sunglasses; hoodie/tee/jacket/suit; pants/shorts; sneakers/boots/high-tops; clothing and shoe colors; K/Bitcoin/Ethereum emblems.

Backgrounds: solid, neon grid, space, sunset, orbital halo, transparent. Base and accent colors are editable. Transparent mode omits labels and the backdrop.

Paint: pointer/touch brush, color, size, paint-only eraser, undo last stroke, clear paint. Maximum 200 strokes, 400 points per stroke. Keyboard users can use all form-based appearance controls; freehand painting requires a pointing device.

Exports: 800×800 PNG, SVG, draft metadata, and JSON gallery backup. Save up to 50 local avatar drafts, edit copies, feature one, remove, or import backups. Editing saves a new draft rather than overwriting an existing one.

## Install

Upload Mini-K-Avatar-Builder.zip to your repository root. Extract install-avatar.py from it and run:

```bash
python3 install-avatar.py
node --check docs/avatar-design.js
node --check docs/avatar-builder.js
git diff --check
git add docs/avatar-design.js docs/avatar-builder.js docs/nft-studio.html
git commit -m "Add Mini K NFT avatar builder with paint and backgrounds"
git push
```

Alternatively copy the two docs/*.js files into docs/ and add, in this order, before </head> in docs/nft-studio.html:

```html
<script src="avatar-design.js" defer></script>
<script src="avatar-builder.js" defer></script>
```

Refresh NFT Studio. Use the new Build avatar navigation link. Saved avatars appear in My avatar drafts inside the NFT Studio. Existing personal-dashboard links to NFT Studio still work.

## Storage and network status

These are local unminted avatar drafts, visible to anyone using the same browser profile. They are NOT account-synced private records, verified wallet-owned NFTs, or tradeable minted assets. Changing intended network changes metadata only. Existing minting, inscription, account sync and trading integrations remain pending. No keys, wallet connections, transactions, or third-party requests are used here.

Export a backup before clearing browser data. A full/unavailable/corrupt localStorage produces an error rather than reporting a successful save. Draft metadata uses a relative image filename; replace it with the published artwork URI before minting.

## Verification

JavaScript syntax checked. Renderer tests cover all enumerated styles, invalid colors/heights/strokes, XML text escaping, and backup round trips. SVGs for six backgrounds were rendered and visually inspected. Live browser interaction and PNG export still need a browser acceptance check after installation.
