"""Run from the repository root, beside Mini-K-Avatar-Builder.zip."""
from pathlib import Path
from zipfile import ZipFile

page = Path('docs/nft-studio.html')
html = page.read_text()
assets = ['docs/avatar-design.js', 'docs/avatar-builder.js']
with ZipFile('Mini-K-Avatar-Builder.zip') as archive:
    payloads = {name: archive.read(name) for name in assets}
    for name, content in payloads.items():
        if Path(name).exists() and Path(name).read_bytes() != content:
            raise SystemExit(f'Stopped: {name} exists with different contents. Back it up and review before replacing.')
    if '</head>' not in html:
        raise SystemExit('Missing </head>; no files changed.')
    for name, content in payloads.items():
        Path(name).write_bytes(content)
    tags = ''.join(f'<script src="{Path(name).name}" defer></script>\n' for name in assets if f'src="{Path(name).name}"' not in html)
    if tags:
        page.write_text(html.replace('</head>', tags + '</head>', 1))
print('Avatar builder installed. Open docs/nft-studio.html through your website.')
