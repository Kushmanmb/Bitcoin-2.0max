# Bitcoin2.0Max NFT Studio — creator foundation

This package implements a static artwork designer and local draft gallery. It is NOT a working minting or trading service. No wallet transactions are requested.

## Install

Copy the three files in `docs/` into your repository's `docs/` directory.

In `docs/index.html`, inside `<ul class="nav__links" id="navLinks">`, add:

```html
<li><a href="nft-studio.html">NFT Studio ↗</a></li>
```

In `docs/dashboard.html`, immediately AFTER the closing `</nav>` for `workspaceNav`, add:

```html
<a class="nav-item" href="nft-studio.html#gallery"><span>◈</span>My NFT Studio</a>
```

The studio is a separate personal creative-space page linked from the dashboard. It does not yet embed a collection in the account overview. Keeping the anchor outside workspaceNav avoids interference with dashboard view handlers.

Commit these files and links. GitHub Pages can serve the designer without an account server. Open `nft-studio.html` beside your existing index page.

## Available

- Three generative vector styles, colors, variation, title, signature, description.
- Live SVG preview and SVG download.
- Up to 100 local drafts, featured artwork, editing as a new draft, removal.
- JSON gallery backup/import with size and schema validation.
- Draft Ethereum metadata export. Replace its relative `image` value with the durable published artwork URI before minting.
- Intended Bitcoin/Ethereum network label; this selection does not issue an asset.

## Required to finish the requested network features

1. Deploy the existing account backend. Add authenticated, owner-scoped artwork records and storage; enforce permissions server-side. Browser drafts are shared across accounts on the same browser and must not be described as private account storage.
2. Ethereum: choose a maintained NFT contract implementation, test on a test network, publish durable media and metadata, deploy and verify the contract, integrate wallet discovery and chain validation, simulate/estimate mint transactions, and confirm receipts before marking a token minted. Contract deployment and gas require a funded wallet.
3. Bitcoin: choose an inscription provider/wallet integration; support fee quotes, content limits, commit/reveal flow, cancellation/failure recovery, inscription indexing, and ownership verification. Keep ordinal-bearing UTXOs separate from ordinary payment handling.
4. Gallery: index assets by verified wallet ownership and network. Keep local drafts separate from confirmed assets; only publish galleries with user consent.
5. Trading: select a marketplace integration, verify asset identity and ownership, show approval scope and fees, require wallet confirmation, and confirm settlement. A transfer is not a trustless trade; implement reviewed exchange settlement before allowing direct swaps.

Acceptance gate: demonstrate mint/inscribe -> verify ownership -> display -> list -> settle -> update ownership, with rejected signatures, failed transactions, stale quotes, and provider outages handled.

No mainnet contract, inscription service, storage provider, marketplace, or account sync has been configured in this package. Publishing and trading buttons are deliberately disabled and labelled.

## Checks

JavaScript syntax checked with `node --check docs/nft-studio.js`. Browser rendering and network mint/trade flows are not verified.
